traffic <- read.csv(file="traffic.csv",head=TRUE,sep=";")
traffic<-na.omit(traffic)
traffic_log=data.frame(traffic);
traffic_log$L101_volume=log(as.numeric(traffic_log$L101_volume));

## Traffic Volume is defined as the procedure to determine mainly volume of traffic moving on the roads at a particular section during a particular time.
##Traffic Occupancy is defined as: "the percent of time the detection zone of a detector is occupied by some vehicle.
cat("\014")

traffic$L101_volume=as.numeric(traffic$L101_volume);
k=4
#traffic_log<-na.omit(traffic_log$L101_volume)
mse=NULL
#Mean Absolute Error Median, Absolute Error and Symmetric Median Absolute Percentage Error
mae=NULL
medae=NULL
smdape=NULL

pred=rep(0,8000)
pred.lad=rep(0,8000)
folds=sample(1:k,nrow(traffic_log),replace=TRUE)
#powers = c(2,4,6,8)


#Mean value of Mean Absolute Error Median, Absolute Error and Symmetric Median Absolute Percentage Error
mean.mae = NULL
mean.medae = NULL
mean.smdape = NULL

#applying 4-fold (each fold should be correspond to one week of data) cross-validation to examine the predictive power of polynomials of occupancies with orders 2 ,4, 6, 8
#on volumes
for(i in c(2,4,6,8)){
  for(j in 1:k){
    L101_volume=as.numeric(traffic$L101_volume);
    #Estimated models using conventional least squares
    rlm_log_fit=rlm(traffic_log$L101_volume~poly(traffic_log$L101_occupancy,i),data=traffic_log[folds!=j,])
    #
    pred=predict(rlm_log_fit,traffic_log[folds==j,])
    mse[j]=mean((traffic_log$L101_volume[folds==j]-pred)^2)
    mae[j]=mean(abs(traffic_log$L101_volume[folds==j]-pred))
    medae[j]=median(abs(traffic_log$L101_volume[folds==j]-pred))
    smdape[j]=median(200*(abs(traffic_log$L101_volume[folds==j]-pred)/(traffic_log$L101_volume[folds==j]+pred)))
    #median regression
    #lad.rlm_log_fit=rq(L101_volume~L101_occupancy,data=traffic_log[folds!=j,])
    #pred.lad=predict(lad.rlm_log_fit,traffic_log[folds==maj,])
  }
  
  #Mean value of MAE,MEDAE,sMdape for 2,4,6,8 powers of polynomials 
  mean.mae[i/2]=mean(mae)
  mean.medae[i/2]=mean(medae)
  mean.smdape[i/2]=mean(smdape)
}


