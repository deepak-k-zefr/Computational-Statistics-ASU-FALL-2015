##Converting to data frame to access rows and columns
mae1=data.frame(MAE)
medae1=data.frame(MEDAE)
smdape1=data.frame(SMDAPE)

##Commands that were used to plot all the figures 
plot(mae1$[1:4]~c(2,4,6,8),type="l",main="MAE vs poly power for lm()",xlab = "power",ylab ="MAE",ylim =c(4,12),cex=0.5,col=1,lwd=3 )

lines(mae1$X102[1:4]~c(2,4,6,8),type="l",lwd=3,col=2 )
lines(mae1$X103[1:4]~c(2,4,6,8),type="l",lwd=3,col=3 )
lines(mae1$X104[1:4]~c(2,4,6,8),type="p",lwd=3,col=4 )
labels=c("L101","L102","L103","L104")
legend("topright",title="Legend",labels,lwd=3,col=c(1,2,3,4))


plot(mae1$X101[5:8]~c(2,4,6,8),type="l",main="MAE vs poly power for rlm()",xlab = "power",ylab ="MAE",ylim =c(4,12),cex=0.5,col=1,lwd=3 )
lines(mae1$X102[5:8]~c(2,4,6,8),type="p",lwd=3,col=2 )
lines(mae1$X103[5:8]~c(2,4,6,8),type="p",lwd=3,col=3 )
lines(mae1$X104[5:8]~c(2,4,6,8),type="l",lwd=3,col=4 )
labels=c("L101","L102","L103","L104")
legend("topright",title="Legend",labels,lwd=3,col=c(1,2,3,4))



plot(smdape1$X101[1:4]~c(2,4,6,8),type="l",main="smdape vs poly power for lm()",xlab = "power",ylab ="smdape",ylim =c(0,25),cex=0.5,col=1,lwd=3 )
lines(smdape1$X102[1:4]~c(2,4,6,8),type="p",lwd=3,col=2 )
lines(smdape1$X103[1:4]~c(2,4,6,8),type="p",lwd=3,col=3 )
lines(smdape1$X104[1:4]~c(2,4,6,8),type="l",lwd=3,col=4 )
labels=c("L101","L102","L103","L104")
legend("topright",title="Legend",labels,lwd=3,col=c(1,2,3,4))

plot(as.numeric(mae1[4,])~c("101","102","103","104","106","107","108"),type="l",main="(lm vs rlm vs log-lm vs log-rlm) for power 4",xlab = "Data",ylab ="MAE",ylim =c(5,10),cex=0.5,col=1,lwd=6 )
lines(as.numeric(mae1[4,])~c("101","102","103","104","106","107","108"),type="p",lwd=3,col=1 )
lines(as.numeric(mae1[8,])~c("101","102","103","104","106","107","108"),type="l",lwd=3,col=2 )
lines(as.numeric(mae1[8,])~c("101","102","103","104","106","107","108"),type="p",lwd=3,col=2 )
lines(as.numeric(mae1[12,])~c("101","102","103","104","106","107","108"),type="l",lwd=3,col=3 )
lines(as.numeric(mae1[12,])~c("101","102","103","104","106","107","108"),type="p",lwd=3,col=3 )
lines(as.numeric(mae1[16,])~c("101","102","103","104","106","107","108"),type="l",lwd=3,col=4 )
lines(as.numeric(mae1[16,])~c("101","102","103","104","106","107","108"),type="p",lwd=3,col=4 )
labels=c("lm","rlm","log lm","log rlm")
legend("topright",title="POWER",labels,lwd=3,col=c(1,2,3,4))


plot(as.numeric(mae1[1,])~c("101","102","103","104","106","107","108"),type="l",main="smdape vs poly power for lm()",xlab = "power",ylab ="smdape",ylim =c(0,15),cex=0.5,col=1,lwd=3 )

