##Commands that were used to combine all the errors to a single variable- MAE, MEDAE, SMDAPE

  MAE=cbind(mean.mae1,mean.mae2,mean.mae3,mean.mae4,mean.mae6,mean.mae7,mean.mae8,col=7)
  MAE_rlm=cbind(mean.mae.rlm.101,mean.mae.rlm.102,mean.mae.rlm.104,mean.mae.rlm.103,mean.mae.rlm.106,mean.mae.rlm.107,mean.mae.rlm.108,col=7)
  MAE_all=rbind(MAE,MAE_rlm,col=7)
  write.csv(MAE,file="MAE.csv")
  
  
  
  #medae=cbind(mean.medae1,mean.medae2,mean.medae3,mean.medae4,mean.medae6,mean.medae7,mean.medae8,col=7)
  #MEDAE_rlm=cbind(mean.medae.rlm.101,mean.medae.rlm.102,mean.medae.rlm.104,mean.medae.rlm.103,mean.medae.rlm.106,mean.medae.rlm.107,mean.medae.rlm.108,col=7)
  #MEDAE_all=rbind(MEDAE,MEDAE_rlm,col=7)
  #SMDAPE_all=SMDAPE_all[,-8]
  #SMDAPE_all=SMDAPE_all[-9,]
  
  
 
  #unname(SMDAPE_all)
  
  MEDAE_all
  
  SMDAPE=cbind(mean.smdape1,mean.smdape2,mean.smdape3,mean.smdape4,mean.smdape6,mean.smdape7,mean.smdape8,col=7)
  SMDAPE_rlm=cbind(mean.smdape.rlm.101,mean.smdape.rlm.102,mean.smdape.rlm.104,mean.smdape.rlm.103,mean.smdape.rlm.106,mean.smdape.rlm.107,mean.smdape.rlm.108,col=7)
  SMDAPE_all=rbind(SMDAPE,SMDAPE_rlm,col=7)
  MEDAE_log=cbind(mean.medae.log.lm.1,mean.medae.log.lm.2,mean.medae.log.lm.3,mean.medae.log.lm.4,mean.medae.log.lm.6,mean.medae.log.lm.7,mean.medae.log.lm.8,col=7)
  MEDAE_rlm_log=cbind(mean.medae.rlm.log.101,mean.medae.rlm.log.102,mean.medae.rlm.log.103,mean.medae.rlm.log.104,mean.medae.rlm.log.106,mean.medae.rlm.log.107,mean.medae.rlm.log.108,col=7)
  
  MEDAE_log=rbind(MEDAE_log,MEDAE_rlm_log,col=7)
  unname(MEDAE_log)
  
  MEDAE_log=MEDAE_log[-9,-8]
  MEDAE=rbind(MEDAE_all,MEDAE_log,col=7)
  SMDAPE=SMDAPE[-17,]
  dim(SMDAPE)
  rownames(SMDAPE)<-c("Linear-lm(2)","Linear-lm(4)","Linear-lm(6)","Linear-lm(8)","Robust_Linear-rlm(2)","Robust_Linear-rlm(4)","Robust_Linear-rlm(6)","Robust_Linear-rlm(8)","Linear-lm-log(2)","Linear-lm-log(4)","Linear-lm-log(6)","Linear-lm-log(8)","Robust_Linear-rlm-log(2)","Robust_Linear-rlm-log(4)","Robust_Linear-rlm-log(6)","Robust_Linear-rlm-log(8)")
  
 # traffic_log=log(traffic[,1:7]+1)
  #traffic_log=cbind(traffic_log,traffic[8:14]);
  MAE_log=cbind(mean.mae.log.lm.1,mean.mae.log.lm.2,mean.mae.log.lm.3,mean.mae.log.lm.4,mean.mae.log.lm.6,mean.mae.log.lm.7,mean.mae.log.lm.8,col=7)
  MAE_rlm_log=cbind(mean.mae.rlm.log.101,mean.mae.rlm.log.102,mean.mae.rlm.log.103,mean.mae.rlm.log.104,mean.mae.rlm.log.106,mean.mae.rlm.log.107,mean.mae.rlm.log.108,col=7)
  
  MAE_rlm_log=cbind(mean.mae.rlm.log.101,mean.mae.rlm.log.102,mean.mae.rlm.log.103,mean.mae.rlm.log.104,mean.mae.rlm.log.106,mean.mae.rlm.log.107,mean.mae.rlm.log.108,col=7)
  MAE_log
  unname(MAE_rlm_log)
  MAE_log=rbind(MAE_log,MAE_rlm_log,col=7)
  unname(MAE_log)
  MAE_log=MAE_log[-9,-8]
  MAE=rbind(MAE_all,MAE_log,col=7)
  MAE
  dim(MAE)
  MAE=MAE[-17,]
  
  #colnames(MEDAE_all) <- c("101","102","103","104","106","107","108")
  rownames(MAE)<-c("Linear-lm(2)","Linear-lm(4)","Linear-lm(6)","Linear-lm(8)","Robust_Linear-rlm(2)","Robust_Linear-rlm(4)","Robust_Linear-rlm(6)","Robust_Linear-rlm(8)","Linear-lm-log(2)","Linear-lm-log(4)","Linear-lm-log(6)","Linear-lm-log(8)","Robust_Linear-rlm-log(2)","Robust_Linear-rlm-log(4)","Robust_Linear-rlm-log(6)","Robust_Linear-rlm-log(8)")
  #rownames(MAE)<-c("Log-Linear(2)","Linear(4)","Linear(6)","Linear(8)","Robust_Linear(2)","Robust_Linear(4)","Robust_Linear(6)","Robust_Linear(8)")
  
  #xyplot(mae1$X101[1:4]~c(2,4,6,8),type="l",main="MAE vs poly power",xlab = "MAE",ylab ="power",ylim =c(4,12),cex=0.5,col=2,lwd=3 )
  write.csv(MAE,file="MAE.csv")
  write.csv(MEDAE,file="MEDAE.csv")
  write.csv(SMDAPE,file="SMDAPE.csv")
    