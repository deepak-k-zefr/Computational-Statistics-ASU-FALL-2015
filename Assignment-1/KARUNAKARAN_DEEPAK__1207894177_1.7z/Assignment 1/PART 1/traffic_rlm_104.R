require(foreign)
require(MASS)

## Traffic Volume is defined as the procedure to determine mainly volume of traffic moving on the roads at a particular section during a particular time.
##Traffic Occupancy is defined as: "the percent of time the detection zone of a detector is occupied by some vehicle.
cat("\014")
traffic <- read.csv(file="traffic.csv",head=TRUE,sep=";")
traffic<-na.omit(data.frame(traffic))
k=4
traffic$L104_volume=as.numeric(traffic$L104_volume);
mse=NULL
#Mean Absolute Error Median, Absolute Error and Symmetric Median Absolute Percentage Error
mae.rlm.104=NULL
medae.rlm.104=NULL
smdape.rlm.104=NULL

pred=rep(0,8000)
pred.lad=rep(0,8000)
folds=sample(1:k,nrow(traffic),replace=TRUE)



#Mean value of Mean Absolute Error Median, Absolute Error and Symmetric Median Absolute Percentage Error
mean.mae.rlm.104 = NULL
mean.medae.rlm.104 = NULL
mean.smdape.rlm.104 = NULL

#applying 4-fold (each fold should be correspond to one week of data) cross-validation to examine the predictive power of polynomials of occupancies with orders 2 ,4, 6, 8
#on volumes
for(i in c(2,4,6,8)){
  for(j in 1:k){
    L104_volume=as.numeric(traffic$L104_volume);
    #Estimated models using conventional least squares
    rlm.fit=lm(L104_volume~poly(L104_occupancy,i),data=traffic[folds!=j,])
    
    pred=predict(rlm.fit,traffic[folds==j,])
    
    mae.rlm.104[j]=mean(abs(L104_volume[folds==j]-pred))
    medae.rlm.104[j]=median(abs(L104_volume[folds==j]-pred))
    smdape.rlm.104[j]=median(200*(abs(L104_volume[folds==j]-pred)/(L104_volume[folds==j]+pred)))
  }
  #Mean value of Mae.rlm.104,MEDae.rlm.104,sMdape for 2,4,6,8 powers of polynomials 
  mean.mae.rlm.104[i/2]=mean(mae.rlm.104)
  mean.medae.rlm.104[i/2]=mean(medae.rlm.104)
  mean.smdape.rlm.104[i/2]=mean(smdape.rlm.104)
}


##system.time()