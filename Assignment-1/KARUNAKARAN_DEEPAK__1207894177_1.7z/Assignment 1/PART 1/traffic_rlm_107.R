require(foreign)
require(MASS)

## Traffic Volume is defined as the procedure to determine mainly volume of traffic moving on the roads at a particular section during a particular time.
##Traffic Occupancy is defined as: "the percent of time the detection zone of a detector is occupied by some vehicle.
cat("\014")
traffic <- read.csv(file="traffic.csv",head=TRUE,sep=";")
traffic<-na.omit(data.frame(traffic))
k=4
traffic$L107_volume=as.numeric(traffic$L107_volume);
mse=NULL
#Mean Absolute Error Median, Absolute Error and Symmetric Median Absolute Percentage Error
mae.rlm.107=NULL
medae.rlm.107=NULL
smdape.rlm.107=NULL

pred=rep(0,8000)
pred.lad=rep(0,8000)
folds=sample(1:k,nrow(traffic),replace=TRUE)



#Mean value of Mean Absolute Error Median, Absolute Error and Symmetric Median Absolute Percentage Error
mean.mae.rlm.107 = NULL
mean.medae.rlm.107 = NULL
mean.smdape.rlm.107 = NULL

#applying 4-fold (each fold should be correspond to one week of data) cross-validation to examine the predictive power of polynomials of occupancies with orders 2 ,4, 6, 8
#on volumes
for(i in c(2,4,6,8)){
  for(j in 1:k){
    L107_volume=as.numeric(traffic$L107_volume);
    #Estimated models using conventional least squares
    rlm.fit=lm(L107_volume~poly(L107_occupancy,i),data=traffic[folds!=j,])
    
    pred=predict(rlm.fit,traffic[folds==j,])
    
    mae.rlm.107[j]=mean(abs(L107_volume[folds==j]-pred))
    medae.rlm.107[j]=median(abs(L107_volume[folds==j]-pred))
    smdape.rlm.107[j]=median(200*(abs(L107_volume[folds==j]-pred)/(L107_volume[folds==j]+pred)))
  }
  #Mean value of Mae.rlm.107,MEDae.rlm.107,sMdape for 2,4,6,8 powers of polynomials 
  mean.mae.rlm.107[i/2]=mean(mae.rlm.107)
  mean.medae.rlm.107[i/2]=mean(medae.rlm.107)
  mean.smdape.rlm.107[i/2]=mean(smdape.rlm.107)
}


##system.time()