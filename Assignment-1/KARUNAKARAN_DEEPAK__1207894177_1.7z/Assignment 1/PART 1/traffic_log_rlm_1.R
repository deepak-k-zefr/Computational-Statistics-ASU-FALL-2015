###Rlm for log transformed values

require(foreign)
require(MASS)



k=4
traffic_log$L101_volume=as.numeric(traffic_log$L101_volume);
mse=NULL
#Mean Absolute Error Median, Absolute Error and Symmetric Median Absolute Percentage Error
mae.rlm.log.101=NULL
medae.rlm.log.101=NULL
smdape.rlm.log.101=NULL

pred=rep(0,8000)
pred.lad=rep(0,8000)
folds=sample(1:k,nrow(traffic_log),replace=TRUE)



#Mean value of Mean Absolute Error Median, Absolute Error and Symmetric Median Absolute Percentage Error
mean.mae.rlm.log.101 = NULL
mean.medae.rlm.log.101 = NULL
mean.smdape.rlm.log.101 = NULL

#applying 4-fold (each fold should be correspond to one week of data) cross-validation to examine the predictive power of polynomials of occupancies with orders 2 ,4, 6, 8
#on volumes
for(i in c(2,4,6,8)){
  for(j in 1:k){
    L101_volume=as.numeric(traffic_log$L101_volume);
    #Estimated models using conventional least squares
    rlm.fit=lm(L101_volume~poly(L101_occupancy,i),data=traffic_log[folds!=j,])
    
    pred=predict(rlm.fit,traffic_log[folds==j,])
    
    mae.rlm.log.101[j]=mean(abs(exp(L101_volume[folds==j])-exp(pred)-1))
    medae.rlm.log.101[j]=median(abs(exp(L101_volume[folds==j])-exp(pred)-1))
    smdape.rlm.log.101[j]=median((200*(abs(exp(L101_volume[folds==j]))-exp(pred)-1)/exp(L101_volume[folds==j])+exp(pred-1)))
    
  }
  #Mean value of Mae.rlm.log.101,MEDae.rlm.log.101,sMdape for 2,4,6,8 powers of polynomials 
  mean.mae.rlm.log.101[i/2]=mean(mae.rlm.log.101)
  mean.medae.rlm.log.101[i/2]=mean(medae.rlm.log.101)
  mean.smdape.rlm.log.101[i/2]=mean(smdape.rlm.log.101)
}


##system.time()