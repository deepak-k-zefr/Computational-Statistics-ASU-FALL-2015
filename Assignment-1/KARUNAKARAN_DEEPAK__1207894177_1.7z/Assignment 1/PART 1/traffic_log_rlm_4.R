###Rlm for log transformed values

require(foreign)
require(MASS)



k=4
traffic_log$L104_volume=as.numeric(traffic_log$L104_volume);
mse=NULL
#Mean Absolute Error Median, Absolute Error and Symmetric Median Absolute Percentage Error
mae.rlm.log.104=NULL
medae.rlm.log.104=NULL
smdape.rlm.log.104=NULL

pred=rep(0,8000)
pred.lad=rep(0,8000)
folds=sample(1:k,nrow(traffic_log),replace=TRUE)



#Mean value of Mean Absolute Error Median, Absolute Error and Symmetric Median Absolute Percentage Error
mean.mae.rlm.log.104 = NULL
mean.medae.rlm.log.104 = NULL
mean.smdape.rlm.log.104 = NULL

#applying 4-fold (each fold should be correspond to one week of data) cross-validation to examine the predictive power of polynomials of occupancies with orders 2 ,4, 6, 8
#on volumes
for(i in c(2,4,6,8)){
  for(j in 1:k){
    L104_volume=as.numeric(traffic_log$L104_volume);
    #Estimated models using conventional least squares
    rlm.fit=lm(L104_volume~poly(L104_occupancy,i),data=traffic_log[folds!=j,])
    
    pred=predict(rlm.fit,traffic_log[folds==j,])
    
    mae.rlm.log.104[j]=mean(abs(exp(L104_volume[folds==j])-exp(pred)-1))
    medae.rlm.log.104[j]=median(abs(exp(L104_volume[folds==j])-exp(pred)-1))
    smdape.rlm.log.104[j]=median((200*(abs(exp(L104_volume[folds==j]))-exp(pred)-1)/exp(L104_volume[folds==j])+exp(pred-1)))
    
  }
  #Mean value of Mae.rlm.log.104,MEDae.rlm.log.104,sMdape for 2,4,6,8 powers of polynomials 
  mean.mae.rlm.log.104[i/2]=mean(mae.rlm.log.104)
  mean.medae.rlm.log.104[i/2]=mean(medae.rlm.log.104)
  mean.smdape.rlm.log.104[i/2]=mean(smdape.rlm.log.104)
}


##system.time()