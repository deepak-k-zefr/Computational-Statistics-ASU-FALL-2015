#rm(list=ls(all=TRUE))
## traffic_log Volume is defined as the procedure to determine mainly volume of traffic_log moving on the roads at a particular section during a particular time.
##traffic_log Occupancy is defined as: "the percent of time the detection zone of a detector is occupied by some vehicle.
cat("\014")

k=4
traffic_log$L102_volume=as.numeric(traffic_log$L102_volume)
mse=NULL
#Mean Absolute Error Median, Absolute Error and Symmetric Median Absolute Percentage Error
mae.log.lm.2=NULL
medae.log.lm.2=NULL
smdape.log.lm.2=NULL

pred=rep(0,times=10000)
pred.lad=rep(0,times=10000)
folds=sample(1:k,nrow(traffic_log),replace=TRUE)

#Mean value of Mean Absolute Error Median, Absolute Error and Symmetric Median Absolute Percentage Error
mean.mae.log.lm.2 = NULL
mean.medae.log.lm.2 = NULL
mean.smdape.log.lm.2= NULL

#applying 4-fold (each fold should be correspond to one week of data) cross-validation to examine the predictive power of polynomials of occupancies with orders 2 ,4, 6, 8
#on volumes
for(i in 1:4){
  for(j in 1:k){
    L102_volume=as.numeric(traffic_log$L102_volume)
    #Estimated models using conventional least squares
    fit=lm(L102_volume~poly(L102_occupancy,2*i),data=traffic_log[folds!=j,])
    pred=predict(fit,traffic_log[folds==j,])
    mae.log.lm.2[j]=mean(abs(L102_volume[folds==j]-pred))
    medae.log.lm.2[j]=median(abs(L102_volume[folds==j]-pred))
    smdape.log.lm.2[j]=median(200*(abs(L102_volume[folds==j]-pred)/(L102_volume[folds==j]+pred)))
  }
  #Mean value of MAE,MEDAE,sMdape for 2,4,6,8 powers of polynomials 
  mean.mae.log.lm.2[i]=mean(mae.log.lm.2)
  mean.medae.log.lm.2[i]=mean(medae.log.lm.2)
  mean.smdape.log.lm.2[i]=mean(smdape.log.lm.2)
}
#system.time()