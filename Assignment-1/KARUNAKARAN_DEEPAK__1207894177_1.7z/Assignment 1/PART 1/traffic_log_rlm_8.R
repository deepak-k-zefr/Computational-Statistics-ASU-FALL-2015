###Rlm for log transformed values

require(foreign)
require(MASS)



k=4
traffic_log$L108_volume=as.numeric(traffic_log$L108_volume);
mse=NULL
#Mean Absolute Error Median, Absolute Error and Symmetric Median Absolute Percentage Error
mae.rlm.log.108=NULL
medae.rlm.log.108=NULL
smdape.rlm.log.108=NULL

pred=rep(0,8000)
pred.lad=rep(0,8000)
folds=sample(1:k,nrow(traffic_log),replace=TRUE)



#Mean value of Mean Absolute Error Median, Absolute Error and Symmetric Median Absolute Percentage Error
mean.mae.rlm.log.108 = NULL
mean.medae.rlm.log.108 = NULL
mean.smdape.rlm.log.108 = NULL

#applying 4-fold (each fold should be correspond to one week of data) cross-validation to examine the predictive power of polynomials of occupancies with orders 2 ,4, 6, 8
#on volumes
for(i in c(2,4,6,8)){
  for(j in 1:k){
    L108_volume=as.numeric(traffic_log$L108_volume);
    #Estimated models using conventional least squares
    rlm.fit=lm(L108_volume~poly(L108_occupancy,i),data=traffic_log[folds!=j,])
    
    pred=predict(rlm.fit,traffic_log[folds==j,])
    
    mae.rlm.log.108[j]=mean(abs(exp(L108_volume[folds==j])-exp(pred)-1))
    medae.rlm.log.108[j]=median(abs(exp(L108_volume[folds==j])-exp(pred)-1))
    smdape.rlm.log.108[j]=median((200*(abs(exp(L108_volume[folds==j]))-exp(pred)-1)/exp(L108_volume[folds==j])+exp(pred-1)))
    
  }
  #Mean value of Mae.rlm.log.108,MEDae.rlm.log.108,sMdape for 2,4,6,8 powers of polynomials 
  mean.mae.rlm.log.108[i/2]=mean(mae.rlm.log.108)
  mean.medae.rlm.log.108[i/2]=mean(medae.rlm.log.108)
  mean.smdape.rlm.log.108[i/2]=mean(smdape.rlm.log.108)
}


##system.time()