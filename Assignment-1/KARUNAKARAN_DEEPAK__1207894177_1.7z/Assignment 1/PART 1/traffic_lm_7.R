#rm(list=ls(all=TRUE))
## Traffic Volume is defined as the procedure to determine mainly volume of traffic moving on the roads at a particular section during a particular time.
##Traffic Occupancy is defined as: "the percent of time the detection zone of a detector is occupied by some vehicle.
cat("\014")
traffic <- read.csv(file="traffic.csv",head=TRUE,sep=";")
traffic<-na.omit(traffic)
k=4
traffic$L107_volume=as.numeric(traffic$L107_volume)
mse=NULL
#Mean Absolute Error Median, Absolute Error and Symmetric Median Absolute Percentage Error
mae7=NULL
medae7=NULL
smdape7=NULL

pred=rep(0,times=10000)
pred.lad=rep(0,times=10000)
folds=sample(1:k,nrow(traffic),replace=TRUE)



#Mean value of Mean Absolute Error Median, Absolute Error and Symmetric Median Absolute Percentage Error
mean.mae7 = NULL
mean.medae7 = NULL
mean.smdape7= NULL

#applying 4-fold (each fold should be correspond to one week of data) cross-validation to examine the predictive power of polynomials of occupancies with orders 2 ,4, 6, 8
#on volumes
for(i in 1:4){
  for(j in 1:k){
    L107_volume=as.numeric(traffic$L107_volume)
    #Estimated models using conventional least squares
    fit=lm(L107_volume~poly(L107_occupancy,2*i),data=traffic[folds!=j,])
    pred=predict(fit,traffic[folds==j,])
    mae7[j]=mean(abs(L107_volume[folds==j]-pred))
    medae7[j]=median(abs(L107_volume[folds==j]-pred))
    smdape7[j]=median(200*(abs(L107_volume[folds==j]-pred)/(L107_volume[folds==j]+pred)))
  }
  #Mean value of MAE,MEDAE,sMdape for 2,4,6,8 powers of polynomials 
  mean.mae7[i]=mean(mae7)
  mean.medae7[i]=mean(medae7)
  mean.smdape7[i]=mean(smdape7)
}
#system.time()