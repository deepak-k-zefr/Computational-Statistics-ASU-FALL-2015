cat("\014")
traffic <- read.csv(file="traffic.csv",head=TRUE,sep=";")
traffic<-na.omit(traffic)
k=4

mse=NULL
mae=NULL
medae=NULL
smdape=NULL

predict.ls=rep(0,8000)
pred=rep(0,8000)
pred.lad=rep(0,8000)
folds=sample(1:k,nrow(traffic),replace=TRUE)
powers = c(2,4,6,8)
mean.mse = NULL
mean.mae = NULL
mean.medae = NULL
mean.smdape = NULL

#pply 4-fold (each fold should be correspond to one week of data) cross-validation to examine the predictive power of polynomials of occupancies with orders 2 ,4, 6, 8
#on volumes
for(i in powers){
  for(j in 1:k){
    
    ls.fit=lm(traffic$L101_volume~poly(traffic$L101_occupancy,i),data=traffic[folds!=j,])
    pred.ls=predict(ls.fit,traffic[folds==j,])
    mse[j]=mean((traffic$L101_volume[folds==j]-pred)^2)
    mae[j]=mean(abs(traffic$L101_volume[folds==j]-pred))
    medae[j]=median(abs(traffic$L101_volume[folds==j]-pred))
    smdape[j]=median(200*(abs(traffic$L101_volume[folds==j]-pred)/(traffic$L101_volume[folds==j]+pred)))
    #median regression
    #lad.fit=rq(L101_volume~L101_occupancy,data=traffic[folds!=j,])
    #pred.lad=predict(lad.fit,traffic[folds==maj,])
  }
  mean.mse[i/2]=mean(mse)
  mean.mae[i/2]=mean(mae)
  mean.medae[i/2]=mean(medae)
  mean.smdape[i/2]=mean(smdape)
}