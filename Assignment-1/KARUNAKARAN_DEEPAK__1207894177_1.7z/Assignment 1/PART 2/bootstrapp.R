

# Bootstrap 95% CI for regression coefficients
library(boot)
# function to obtain regression weights
bs <- function(formula, data, indices) {
  d <- data[indices,] # allows boot to select sample
  fit <- lm(formula, data=d)
  return(coef(fit))
}
# bootstrapping with 1000 replications
traffic_short=data.frame(traffic$L104_volume,traffic$L104_occupancy)
results <- boot(data=traffic_short, statistic=bs, R=5, formula=L101_volume~poly(L101_occupancy,6))

# view results
results
plot(results, index=1) # intercept


# get 95% confidence intervals
#boot.ci(results, type="bca", index=1) # intercept
