fitthetahat.b=NULL
traffic<-na.omit(traffic)
  ### create our data
oursample = traffic

  fit_theta=lm(L103_volume~poly(L103_occupancy,6),data=traffic)$coeff[2] 
 
  fit_theta.b = rep(NA,1000); 
for (i in 1:10000) {
   index = 1:100
  bootindex = sample(index, 100, replace=T)
  bootsample = oursample[bootindex,]
  fitthetahat.b[i] = lm(L103_volume~poly(L103_occupancy,6),bootsample)$coeff[2]
 }
hist(fitthetahat.b);
quantile(fitthetahat.b, .025); quantile(fitthetahat.b, .975)

