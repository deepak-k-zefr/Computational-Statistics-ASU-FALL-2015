# Load the textbook R package
require(ISLR)
# Load in the credit data
attach(Default)
library(manipulate)
str(Default)

attach(Default) 
table1<-table(Default$default)  
(table1[[2]]/table1[[1]])*100 


#Fitting a multiple logistic regression model that uses income and balance to predict the probability of default
set.seed(122)
logit1.fit=glm(default~income+balance,data=Default, family="binomial")

# Validation approach three times using three different splits of the observations into a training set and a validation set
set.seed(15)
# We randomly split the sample set into two equal halves- training set and a validation set. 
train <-  sample(dim(Default)[1], 5000) 
#Then we fit a multiple logistic regression model using only the training observations. 
logit.fit <-  glm(default ~ income + balance, data = Default, family = binomial,subset = train) 
#We compute the validation set error, which is the fraction of the observations in the validation set that are misclassified. 
logit.pred <-  rep("No", 5000) 
logit.prob <-  predict(glm.fit, Default[-train, ], type = "response") 
logit.pred[logit.prob > 0.5] <-  "Yes" 
mean(logit.pred != Default[-train, ]$default)*100 






# Validation approach three times using three different splits of the observations into a training set and a validation set
set.seed(135)
# We randomly split the sample set into - training set and a validation set. 
train <-  sample(dim(Default)[1], 5000) 
#Then we fit a multiple logistic regression model using only the training observations. 
logit.fit <-  glm(default ~ income + balance, data = Default, family = binomial,subset = train) 
#We compute the validation set error, which is the fraction of the observations in the validation set that are misclassified. 
logit.pred <-  rep("No", 5000) 
logit.prob <-  predict(glm.fit, Default[-train, ], type = "response") 
logit.pred[logit.prob > 0.5] <-  "Yes" 
mean(logit.pred != Default[-train, ]$default)*100 

# Validation approach three times using three different splits of the observations into a training set and a validation set
set.seed(135)
# We randomly split the sample set into - training set and a validation set. 
train <-  sample(dim(Default)[1], 5000) 
#Then we fit a multiple logistic regression model using only the training observations. 
logit.fit <-  glm(default ~ income + balance, data = Default, family = binomial,subset = train) 
#We compute the validation set error, which is the fraction of the observations in the validation set that are misclassified. 
logit.pred <-  rep("No", 5000) 
logit.prob <-  predict(glm.fit, Default[-train, ], type = "response") 
logit.pred[logit.prob > 0.5] <-  "Yes" 
mean(logit.pred != Default[-train, ]$default)*100 


# Considering a 50% threshold for probability of default.



#EXTREME threholds
logit.pred[logit.prob > 0.1] <-  "Yes" 
logit.pred[logit.prob > 0.9] <-  "Yes" 

#Now consider a logistic regression model that predicts the probability of 
#default using income, balance, and a dummy variable for student

set.seed(135)
 train <-  sample(dim(Default)[1], 5000) 
logit.fit <-  glm(default ~ income + balance + student, data = Default, family = binomial,subset = train) 
logit.pred <-  rep("No", 5000) 
logit.prob <-  predict(glm.fit, Default[-train, ], type = "response") 
logit.pred[logit.prob > 0.5] <-  "Yes" 
mean(logit.pred != Default[-train, ]$default)*100 

summary(logit.fit)$coeff[,1]






library(ggplot2)

#
qplot(Default$income,Default$default) 
qplot(Default$student,Default$default) 




#Logistic regression PLOT

x <- seq(-10, 10, length = 1000)
manipulate(
  plot(x, exp(beta0 + beta1 * x+beta2*x) / (1 + exp(beta0 + beta1 * x+beta2*x)),
       type = "l", lwd = 3, frame = FALSE),
  beta1 = slider(-2, 2, step = .1, initial = 2),
  beta0 = slider(-2, 2, step = .1, initial = 0))
 
library(boot)
boot.fn=function(data,index){
coefficients(glm(default~income+balance, data=data, subset=index, family="binomial"))
}

boot.fn(Default,1:nrow(Default))



#Bootrap correlations pearson
library(boot)
bs=function(Default,i)cor(Default$income[i],Default$balance[i],use="complete.obs",method="pearson")
b_pearson=boot(Default,bs,2000)
#Bootrap correlations pearson
library(boot)
bs=function(Default,i)cor(Default$income[i],Default$balance[i],use="complete.obs",method="spearman")
b_spearman=boot(Default,bs,2000)
